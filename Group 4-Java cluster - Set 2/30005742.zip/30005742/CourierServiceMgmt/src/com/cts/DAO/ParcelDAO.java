package com.cts.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cts.model.Parcel;
import com.cts.util.DatabaseConnection;

public class ParcelDAO {
	
	public void addParcel(Parcel parcel) throws SQLException {
        String sql = "INSERT INTO Parcel (sender_name, sender_address, recipient_name, recipient_address, weight, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, parcel.getSenderName());
            pstmt.setString(2, parcel.getSenderAddress());
            pstmt.setString(3, parcel.getRecipientName());
            pstmt.setString(4, parcel.getRecipientAddress());
            pstmt.setDouble(5, parcel.getWeight());
            pstmt.setString(6, parcel.getStatus());
            pstmt.executeUpdate();
        }
    }

    public List<Parcel> getAllParcels() throws SQLException {
        String sql = "SELECT * FROM Parcel";
        List<Parcel> parcels = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Parcel parcel = new Parcel();
                parcel.setParcelID(rs.getInt("parcel_id"));
                parcel.setSenderName(rs.getString("sender_name"));
                parcel.setSenderAddress(rs.getString("sender_address"));
                parcel.setRecipientName(rs.getString("recipient_name"));
                parcel.setRecipientAddress(rs.getString("recipient_address"));
                parcel.setWeight(rs.getDouble("weight"));
                parcel.setStatus(rs.getString("status"));
                parcels.add(parcel);
            }
        }
        return parcels;
    }

    public void updateParcel(Parcel parcel) throws SQLException {
        String sql = "UPDATE Parcel SET sender_name = ?, sender_address = ?, recipient_name = ?, recipient_address = ?, weight = ?, status = ? WHERE parcel_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, parcel.getSenderName());
            pstmt.setString(2, parcel.getSenderAddress());
            pstmt.setString(3, parcel.getRecipientName());
            pstmt.setString(4, parcel.getRecipientAddress());
            pstmt.setDouble(5, parcel.getWeight());
            pstmt.setString(6, parcel.getStatus());
            pstmt.setInt(7, parcel.getParcelID());
            pstmt.executeUpdate();
        }
    }

    public void deleteParcel(int parcelID) throws SQLException {
        String sql = "DELETE FROM Parcel WHERE parcel_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, parcelID);
            pstmt.executeUpdate();
        }
    }

}
