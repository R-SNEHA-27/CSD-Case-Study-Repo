package com.cts.controller;

import java.sql.Date;
import java.sql.SQLException;
import java.util.*;

import com.cts.DAO.*;
import com.cts.model.*;

public class CourierService {
	
	private static Scanner scanner = new Scanner(System.in);
    private static CustomerDAO customerDAO = new CustomerDAO();
    private static ParcelDAO parcelDAO = new ParcelDAO();
    private static DeliveryDAO deliveryDAO = new DeliveryDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nCourier Service Management System");
            System.out.println("1. Manage Customers");
            System.out.println("2. Manage Parcels");
            System.out.println("3. Manage Deliveries");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    manageCustomers();
                    break;
                case 2:
                    manageParcels();
                    break;
                case 3:
                    manageDeliveries();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageCustomers() {
        while (true) {
            System.out.println("\nManage Customers");
            System.out.println("1. Add Customer");
            System.out.println("2. View All Customers");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    viewAllCustomers();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    deleteCustomer();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addCustomer() {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String phone = scanner.nextLine();

        Customer customer = new Customer();
        customer.setCustomerName(name);
        customer.setEmail(email);
        customer.setPhoneNumber(phone);

        try {
            customerDAO.addCustomer(customer);
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllCustomers() {
        try {
            List<Customer> customers = customerDAO.getAllCustomers();
            System.out.println("ID " + "\t" + "Name " + "\t" + "Email " + "\t\t\t" + "Phone");
            for (Customer customer : customers) {
                System.out.println(customer.getCustomerID() + "\t" + customer.getCustomerName() + "\t" + customer.getEmail() + "\t\t" + customer.getPhoneNumber());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateCustomer() {
        System.out.print("Enter customer ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new phone number: ");
        String phone = scanner.nextLine();

        Customer customer = new Customer();
        customer.setCustomerID(id);
        customer.setCustomerName(name);
        customer.setEmail(email);
        customer.setPhoneNumber(phone);

        try {
            customerDAO.updateCustomer(customer);
            System.out.println("Customer updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteCustomer() {
        System.out.print("Enter customer ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        try {
            customerDAO.deleteCustomer(id);
            System.out.println("Customer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void manageParcels() {
        while (true) {
            System.out.println("\nManage Parcels");
            System.out.println("1. Add Parcel");
            System.out.println("2. View All Parcels");
            System.out.println("3. Update Parcel");
            System.out.println("4. Delete Parcel");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addParcel();
                    break;
                case 2:
                    viewAllParcels();
                    break;
                case 3:
                    updateParcel();
                    break;
                case 4:
                    deleteParcel();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addParcel() {
        System.out.print("Enter sender name: ");
        String senderName = scanner.nextLine();
        System.out.print("Enter sender address: ");
        String senderAddress = scanner.nextLine();
        System.out.print("Enter recipient name: ");
        String recipientName = scanner.nextLine();
        System.out.print("Enter recipient address: ");
        String recipientAddress = scanner.nextLine();
        System.out.print("Enter weight: ");
        double weight = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter status: ");
        String status = scanner.nextLine();

        Parcel parcel = new Parcel();
        parcel.setSenderName(senderName);
        parcel.setSenderAddress(senderAddress);
        parcel.setRecipientName(recipientName);
        parcel.setRecipientAddress(recipientAddress);
        parcel.setWeight(weight);
        parcel.setStatus(status);

        try {
            parcelDAO.addParcel(parcel);
            System.out.println("Parcel added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllParcels() {
        try {
            List<Parcel> parcels = parcelDAO.getAllParcels();
            System.out.println("ID " + "\t" + "Sender " + "\t" + "Recipient " + "\t" + "Weight " + "\t" + "Status ");
            for (Parcel parcel : parcels) {
                System.out.println(parcel.getParcelID() + "\t" + parcel.getSenderName() + "\t" + parcel.getRecipientName() + "\t\t" + parcel.getWeight() + "\t" + parcel.getStatus());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateParcel() {
        System.out.print("Enter parcel ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new sender name: ");
        String senderName = scanner.nextLine();
        System.out.print("Enter new sender address: ");
        String senderAddress = scanner.nextLine();
        System.out.print("Enter new recipient name: ");
        String recipientName = scanner.nextLine();
        System.out.print("Enter new recipient address: ");
        String recipientAddress = scanner.nextLine();
        System.out.print("Enter new weight: ");
        double weight = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter new status: ");
        String status = scanner.nextLine();

        Parcel parcel = new Parcel();
        parcel.setParcelID(id);
        parcel.setSenderName(senderName);
        parcel.setSenderAddress(senderAddress);
        parcel.setRecipientName(recipientName);
        parcel.setRecipientAddress(recipientAddress);
        parcel.setWeight(weight);
        parcel.setStatus(status);

        try {
            parcelDAO.updateParcel(parcel);
            System.out.println("Parcel updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteParcel() {
        System.out.print("Enter parcel ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        try {
            parcelDAO.deleteParcel(id);
            System.out.println("Parcel deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void manageDeliveries() {
        while (true) {
            System.out.println("\nManage Deliveries");
            System.out.println("1. Schedule Delivery");
            System.out.println("2. View All Deliveries");
            System.out.println("3. Update Delivery Status");
            System.out.println("4. Delete Delivery");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    scheduleDelivery();
                    break;
                case 2:
                    viewAllDeliveries();
                    break;
                case 3:
                    updateDelivery();
                    break;
                case 4:
                    deleteDelivery();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void scheduleDelivery() {
        System.out.print("Enter parcel ID: ");
        int parcelID = scanner.nextInt();
        System.out.print("Enter customer ID: ");
        int customerID = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter delivery date (YYYY-MM-DD): ");
        String deliveryDate = scanner.nextLine();
        System.out.print("Enter delivery status: ");
        String deliveryStatus = scanner.nextLine();

        Delivery delivery = new Delivery();
        delivery.setParcelID(parcelID);
        delivery.setCustomerID(customerID);
        delivery.setDeliveryDate(Date.valueOf(deliveryDate));
        delivery.setDeliveryStatus(deliveryStatus);

        try {
        	delivery.setDeliveryCost(deliveryDAO.calculateDeliveryCost(parcelID));
            deliveryDAO.addDelivery(delivery);
            System.out.println("Delivery scheduled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllDeliveries() {
        try {
            List<Delivery> deliveries = deliveryDAO.getAllDeliveries();
            System.out.println("ID " + "\t" + "Parcel ID " + "\t" + "Customer ID " + "\t" + " Date " + "\t\t" + "Status " + "\t\t" + " Cost ");
            for (Delivery delivery : deliveries) {
                System.out.println(delivery.getDeliveryID() + "\t" + delivery.getParcelID() + "\t\t" + delivery.getCustomerID() + "\t\t" + delivery.getDeliveryDate() + "\t" + delivery.getDeliveryStatus() + "\t" + delivery.getDeliveryCost());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateDelivery() {
        System.out.print("Enter delivery ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new delivery status: ");
        String deliveryStatus = scanner.nextLine();

        try {
        	Delivery delivery = deliveryDAO.getDeliveryById(id); 
            delivery.setDeliveryStatus(deliveryStatus);
            delivery.setDeliveryCost(deliveryDAO.calculateDeliveryCost(delivery.getParcelID()));
            deliveryDAO.updateDelivery(delivery);
            System.out.println("Delivery updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteDelivery() {
        System.out.print("Enter delivery ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        try {
            deliveryDAO.deleteDelivery(id);
            System.out.println("Delivery deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
